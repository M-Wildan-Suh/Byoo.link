<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['value', 'placeholder', 'name', 'submit']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['value', 'placeholder', 'name', 'submit']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="flex flex-row w-full border border-transparent focus-within:border-byolink-3 focus-within:ring-1 focus-within:ring-black rounded-md">
    <input type="text" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder); ?>" value="<?php echo e($value); ?>" class="flex-grow text-sm sm:text-base rounded-l-md border border-r-0 border-byolink-1 focus:ring-0 focus:border-none bg-neutral-100">
    <button class=" text-sm sm:text-base py-2 px-3 border border-byolink-2 border-l-0 bg-byolink-2 text-white rounded-r-md hover:bg-black hover:border-black duration-300"><?php echo e($submit ?? 'Ganti'); ?></button>
</div><?php /**PATH C:\Byoo.link\resources\views/components/admin/component/sectiontitleinput.blade.php ENDPATH**/ ?>