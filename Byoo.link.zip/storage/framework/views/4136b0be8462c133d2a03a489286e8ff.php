<?php if(isset($data->youtube->embed)): ?>
    <div class=" w-full px-4">
        <div class=" w-full aspect-video overflow-hidden rounded">
            <iframe class="w-full h-full"
                src="<?php echo e($data->youtube->embed); ?>"
                title="YouTube video player" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
    </div>
<?php endif; ?><?php /**PATH C:\Byoo.link\resources\views/components/guest/component/youtube.blade.php ENDPATH**/ ?>