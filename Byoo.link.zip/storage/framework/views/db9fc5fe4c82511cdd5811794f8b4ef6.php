<?php if (isset($component)) { $__componentOriginalfef0857b03f2ee29d91db298d4041a2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfef0857b03f2ee29d91db298d4041a2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.layout.online-shop','data' => ['admin' => $admin,'data' => $data]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.layout.online-shop'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin),'data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data)]); ?>
    <div class="min-h-screen">
        
        <?php if (isset($component)) { $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.product','data' => ['slug' => ''.e($data->url).'','background' => $data->templatecolor->bg_color ?? 'white','title' => $data->content->product_title ?? null,'color' => $data->templatecolor->second_color ?? '#EAB653','product' => $data->product ?? [],'class' => 'font-bold','modulstatus' => session('product', false),'type' => $data->template->product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->bg_color ?? 'white'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->content->product_title ?? null),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->second_color ?? '#EAB653'),'product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->product ?? []),'class' => 'font-bold','modulstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('product', false)),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->template->product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $attributes = $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $component = $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfef0857b03f2ee29d91db298d4041a2f)): ?>
<?php $attributes = $__attributesOriginalfef0857b03f2ee29d91db298d4041a2f; ?>
<?php unset($__attributesOriginalfef0857b03f2ee29d91db298d4041a2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfef0857b03f2ee29d91db298d4041a2f)): ?>
<?php $component = $__componentOriginalfef0857b03f2ee29d91db298d4041a2f; ?>
<?php unset($__componentOriginalfef0857b03f2ee29d91db298d4041a2f); ?>
<?php endif; ?><?php /**PATH C:\Byoo.link\resources\views/guest/online-shop/product.blade.php ENDPATH**/ ?>