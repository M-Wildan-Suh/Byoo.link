<?php if (isset($component)) { $__componentOriginal0365313496e5a2bde253eee7e7f8a0f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0365313496e5a2bde253eee7e7f8a0f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.layout.minicompro','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.layout.minicompro'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div x-data="{ admin: <?php echo e($admin ? 'true' : 'false'); ?> }" style="background-color: <?php echo e($data->templatecolor->bg_color ?? 'white'); ?>" class=" w-full max-w-[420px] min-h-screen mx-auto pt-8 sm:pt-4 sm:my-8 rounded-lg shadow-lg shadow-black/35">
        <?php if($admin): ?>
            <?php echo $__env->make('components.guest.component.adminmode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <div class=" space-y-6">
            
            <?php if (isset($component)) { $__componentOriginal9ba3e9a7bf0093d116d1cbf8dae24765 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ba3e9a7bf0093d116d1cbf8dae24765 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.logo','data' => ['slug' => ''.e($data->url).'','image' => ''.e(($data->logo ?? '') != '' ? asset('storage/images/logo/' . $data->logo) : asset('assets/images/placeholder.webp')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','image' => ''.e(($data->logo ?? '') != '' ? asset('storage/images/logo/' . $data->logo) : asset('assets/images/placeholder.webp')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ba3e9a7bf0093d116d1cbf8dae24765)): ?>
<?php $attributes = $__attributesOriginal9ba3e9a7bf0093d116d1cbf8dae24765; ?>
<?php unset($__attributesOriginal9ba3e9a7bf0093d116d1cbf8dae24765); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ba3e9a7bf0093d116d1cbf8dae24765)): ?>
<?php $component = $__componentOriginal9ba3e9a7bf0093d116d1cbf8dae24765; ?>
<?php unset($__componentOriginal9ba3e9a7bf0093d116d1cbf8dae24765); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginale180f9cb0719c94ec48aead3edb32d9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale180f9cb0719c94ec48aead3edb32d9d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.heading','data' => ['slug' => ''.e($data->url).'','title' => ''.e($data->content->head_title ?? '').'','description' => ''.e($data->content->head_desc ?? '').'','color' => ''.e($data->templatecolor->second_color ?? '#074173').'','class' => 'font-neue','type' => 'heading']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','title' => ''.e($data->content->head_title ?? '').'','description' => ''.e($data->content->head_desc ?? '').'','color' => ''.e($data->templatecolor->second_color ?? '#074173').'','class' => 'font-neue','type' => 'heading']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale180f9cb0719c94ec48aead3edb32d9d)): ?>
<?php $attributes = $__attributesOriginale180f9cb0719c94ec48aead3edb32d9d; ?>
<?php unset($__attributesOriginale180f9cb0719c94ec48aead3edb32d9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale180f9cb0719c94ec48aead3edb32d9d)): ?>
<?php $component = $__componentOriginale180f9cb0719c94ec48aead3edb32d9d; ?>
<?php unset($__componentOriginale180f9cb0719c94ec48aead3edb32d9d); ?>
<?php endif; ?>
            
            <?php if(($tag_position ?? '') === 'top'): ?>
                <?php if (isset($component)) { $__componentOriginala286b071fea77c362537bed460f908f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala286b071fea77c362537bed460f908f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.tags','data' => ['slug' => ''.e($data->url).'','color' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','tag' => $tags,'tagposition' => $tag_position,'modalstatus' => session('tag', false)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.tags'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','color' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','tag' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tags),'tagposition' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tag_position),'modalstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('tag', false))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala286b071fea77c362537bed460f908f4)): ?>
<?php $attributes = $__attributesOriginala286b071fea77c362537bed460f908f4; ?>
<?php unset($__attributesOriginala286b071fea77c362537bed460f908f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala286b071fea77c362537bed460f908f4)): ?>
<?php $component = $__componentOriginala286b071fea77c362537bed460f908f4; ?>
<?php unset($__componentOriginala286b071fea77c362537bed460f908f4); ?>
<?php endif; ?>
            <?php endif; ?>
            
            <div class=" w-full">
                
                <?php if (isset($component)) { $__componentOriginal4736fdbd732803fb0875deb774c48f81 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4736fdbd732803fb0875deb774c48f81 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.separator','data' => ['bgcolor' => ''.e($data->templatecolor->bg_color ?? 'white').'','color' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','type' => $data->template->section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bgcolor' => ''.e($data->templatecolor->bg_color ?? 'white').'','color' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->template->section)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $attributes = $__attributesOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__attributesOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $component = $__componentOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__componentOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
                
                <?php if (isset($component)) { $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.product','data' => ['slug' => ''.e($data->url).'','background' => $data->templatecolor->main_color ?? '#1679AB','title' => $data->content->product_title ?? null,'notlp' => $data->content->product_no_tlp ?? null,'color' => $data->templatecolor->second_color ?? '#074173','product' => $data->product ?? [],'class' => 'font-neue text-white','modulstatus' => session('product', false),'type' => $data->template->product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->main_color ?? '#1679AB'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->content->product_title ?? null),'notlp' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->content->product_no_tlp ?? null),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->second_color ?? '#074173'),'product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->product ?? []),'class' => 'font-neue text-white','modulstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('product', false)),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->template->product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $attributes = $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $component = $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
                
                <?php if (isset($component)) { $__componentOriginal519d2ccfa03e6ff7a49665b74be46685 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal519d2ccfa03e6ff7a49665b74be46685 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.gallery','data' => ['slug' => ''.e($data->url).'','background' => $data->templatecolor->main_color ?? '#1679AB','title' => $data->content->gallery_title ?? null,'color' => $data->templatecolor->second_color ?? '#074173','gallery' => $data->gallery ?? [],'class' => 'font-neue text-white','modalstatus' => session('gallery', false)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->main_color ?? '#1679AB'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->content->gallery_title ?? null),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->second_color ?? '#074173'),'gallery' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->gallery ?? []),'class' => 'font-neue text-white','modalstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('gallery', false))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal519d2ccfa03e6ff7a49665b74be46685)): ?>
<?php $attributes = $__attributesOriginal519d2ccfa03e6ff7a49665b74be46685; ?>
<?php unset($__attributesOriginal519d2ccfa03e6ff7a49665b74be46685); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal519d2ccfa03e6ff7a49665b74be46685)): ?>
<?php $component = $__componentOriginal519d2ccfa03e6ff7a49665b74be46685; ?>
<?php unset($__componentOriginal519d2ccfa03e6ff7a49665b74be46685); ?>
<?php endif; ?>
                
                <?php if (isset($component)) { $__componentOriginal4736fdbd732803fb0875deb774c48f81 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4736fdbd732803fb0875deb774c48f81 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.separator','data' => ['bgcolor' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','color' => ''.e($data->templatecolor->bg_color ?? 'white').'','type' => $data->template->section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bgcolor' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','color' => ''.e($data->templatecolor->bg_color ?? 'white').'','type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->template->section)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $attributes = $__attributesOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__attributesOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $component = $__componentOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__componentOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
            </div>
            
            <?php if (isset($component)) { $__componentOriginale180f9cb0719c94ec48aead3edb32d9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale180f9cb0719c94ec48aead3edb32d9d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.heading','data' => ['slug' => ''.e($data->url).'','title' => ''.e($data->content->foot_title ?? '').'','description' => ''.e($data->content->foot_desc ?? '').'','color' => ''.e($data->templatecolor->second_color ?? '#074173').'','class' => 'font-neue','type' => 'footer']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','title' => ''.e($data->content->foot_title ?? '').'','description' => ''.e($data->content->foot_desc ?? '').'','color' => ''.e($data->templatecolor->second_color ?? '#074173').'','class' => 'font-neue','type' => 'footer']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale180f9cb0719c94ec48aead3edb32d9d)): ?>
<?php $attributes = $__attributesOriginale180f9cb0719c94ec48aead3edb32d9d; ?>
<?php unset($__attributesOriginale180f9cb0719c94ec48aead3edb32d9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale180f9cb0719c94ec48aead3edb32d9d)): ?>
<?php $component = $__componentOriginale180f9cb0719c94ec48aead3edb32d9d; ?>
<?php unset($__componentOriginale180f9cb0719c94ec48aead3edb32d9d); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginalbe319ec52b7488c1946d6865e50f3f2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe319ec52b7488c1946d6865e50f3f2c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.linkicon','data' => ['slug' => ''.e($data->url).'','link' => $data->link ?? null,'templatecolor' => $data->templatecolor,'modalstatus' => session('link', false)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.linkicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->link ?? null),'templatecolor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor),'modalstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('link', false))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe319ec52b7488c1946d6865e50f3f2c)): ?>
<?php $attributes = $__attributesOriginalbe319ec52b7488c1946d6865e50f3f2c; ?>
<?php unset($__attributesOriginalbe319ec52b7488c1946d6865e50f3f2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe319ec52b7488c1946d6865e50f3f2c)): ?>
<?php $component = $__componentOriginalbe319ec52b7488c1946d6865e50f3f2c; ?>
<?php unset($__componentOriginalbe319ec52b7488c1946d6865e50f3f2c); ?>
<?php endif; ?>
            
            <?php if(($tag_position ?? '') === 'bottom'): ?>
                <?php if (isset($component)) { $__componentOriginala286b071fea77c362537bed460f908f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala286b071fea77c362537bed460f908f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.tags','data' => ['slug' => ''.e($data->url).'','color' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','tag' => $tags,'tagposition' => $tag_position,'modalstatus' => session('tag', false)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.tags'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','color' => ''.e($data->templatecolor->main_color ?? '#1679AB').'','tag' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tags),'tagposition' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tag_position),'modalstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('tag', false))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala286b071fea77c362537bed460f908f4)): ?>
<?php $attributes = $__attributesOriginala286b071fea77c362537bed460f908f4; ?>
<?php unset($__attributesOriginala286b071fea77c362537bed460f908f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala286b071fea77c362537bed460f908f4)): ?>
<?php $component = $__componentOriginala286b071fea77c362537bed460f908f4; ?>
<?php unset($__componentOriginala286b071fea77c362537bed460f908f4); ?>
<?php endif; ?>
            <?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginal74e25cd59fc70c905722c1d8717148d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74e25cd59fc70c905722c1d8717148d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.footer','data' => ['slug' => ''.e($data->url).'','phonecolor' => $data->templatecolor->third_color ?? '#1d588d','wacolor' => $data->templatecolor->fourth_color ?? '#25D366','notlp' => ''.e($data->contact->no_tlp ?? '').'','nowa' => ''.e($data->contact->no_wa ?? '').'','class' => 'bg-white/30 backdrop-blur']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','phonecolor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->third_color ?? '#1d588d'),'wacolor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->fourth_color ?? '#25D366'),'notlp' => ''.e($data->contact->no_tlp ?? '').'','nowa' => ''.e($data->contact->no_wa ?? '').'','class' => 'bg-white/30 backdrop-blur']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74e25cd59fc70c905722c1d8717148d2)): ?>
<?php $attributes = $__attributesOriginal74e25cd59fc70c905722c1d8717148d2; ?>
<?php unset($__attributesOriginal74e25cd59fc70c905722c1d8717148d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74e25cd59fc70c905722c1d8717148d2)): ?>
<?php $component = $__componentOriginal74e25cd59fc70c905722c1d8717148d2; ?>
<?php unset($__componentOriginal74e25cd59fc70c905722c1d8717148d2); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0365313496e5a2bde253eee7e7f8a0f4)): ?>
<?php $attributes = $__attributesOriginal0365313496e5a2bde253eee7e7f8a0f4; ?>
<?php unset($__attributesOriginal0365313496e5a2bde253eee7e7f8a0f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0365313496e5a2bde253eee7e7f8a0f4)): ?>
<?php $component = $__componentOriginal0365313496e5a2bde253eee7e7f8a0f4; ?>
<?php unset($__componentOriginal0365313496e5a2bde253eee7e7f8a0f4); ?>
<?php endif; ?><?php /**PATH C:\Byoo.link\resources\views/guest/minicompro/home.blade.php ENDPATH**/ ?>