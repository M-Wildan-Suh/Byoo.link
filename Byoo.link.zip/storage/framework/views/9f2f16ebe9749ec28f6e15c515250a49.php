<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Template']); ?>
    <div class="w-full p-6 bg-white rounded-md shadow-md shadow-black/20">
        <form action="<?php echo e(route('template.update', ['template' => $data->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="space-y-6">
                <div class="w-full grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="w-full h-52 sm:h-60 flex items-center justify-center">
                        <div class=" aspect-square max-h-full max-w-full rounded-md overflow-hidden shadow-md shadow-black/20 ">
                            <?php if (isset($component)) { $__componentOriginalf2a3cf57c6f85304198a47e5ee757121 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2a3cf57c6f85304198a47e5ee757121 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.imageinput','data' => ['title' => 'Nama/Tipe','placeholder' => 'Masukkan nama/tipe web...','value' => ''.e(asset('storage/images/templates/'. $data->image)).'','name' => 'image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.component.imageinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Nama/Tipe','placeholder' => 'Masukkan nama/tipe web...','value' => ''.e(asset('storage/images/templates/'. $data->image)).'','name' => 'image']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2a3cf57c6f85304198a47e5ee757121)): ?>
<?php $attributes = $__attributesOriginalf2a3cf57c6f85304198a47e5ee757121; ?>
<?php unset($__attributesOriginalf2a3cf57c6f85304198a47e5ee757121); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2a3cf57c6f85304198a47e5ee757121)): ?>
<?php $component = $__componentOriginalf2a3cf57c6f85304198a47e5ee757121; ?>
<?php unset($__componentOriginalf2a3cf57c6f85304198a47e5ee757121); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div class="md:col-span-2 w-full space-y-2">
                        <?php if (isset($component)) { $__componentOriginalf286e6dababd6dffb177433dbcbd9cb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.textinput','data' => ['title' => 'Nama/Tipe','placeholder' => 'Masukkan nama/tipe web...','value' => ''.e($data->type).'','name' => 'type']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.component.textinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Nama/Tipe','placeholder' => 'Masukkan nama/tipe web...','value' => ''.e($data->type).'','name' => 'type']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8)): ?>
<?php $attributes = $__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8; ?>
<?php unset($__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf286e6dababd6dffb177433dbcbd9cb8)): ?>
<?php $component = $__componentOriginalf286e6dababd6dffb177433dbcbd9cb8; ?>
<?php unset($__componentOriginalf286e6dababd6dffb177433dbcbd9cb8); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal707466e2c0192b41712c1b18b9d72417 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal707466e2c0192b41712c1b18b9d72417 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.priceinput','data' => ['title' => 'Harga','placeholder' => 'Masukkan harga...','value' => ''.e($data->price).'','name' => 'price']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.component.priceinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Harga','placeholder' => 'Masukkan harga...','value' => ''.e($data->price).'','name' => 'price']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal707466e2c0192b41712c1b18b9d72417)): ?>
<?php $attributes = $__attributesOriginal707466e2c0192b41712c1b18b9d72417; ?>
<?php unset($__attributesOriginal707466e2c0192b41712c1b18b9d72417); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal707466e2c0192b41712c1b18b9d72417)): ?>
<?php $component = $__componentOriginal707466e2c0192b41712c1b18b9d72417; ?>
<?php unset($__componentOriginal707466e2c0192b41712c1b18b9d72417); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.linkinput','data' => ['title' => 'Demo Url','placeholder' => 'Masukkan link...','value' => ''.e($data->demo_url).'','name' => 'demo_url','link' => ''.e(url('/')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.component.linkinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Demo Url','placeholder' => 'Masukkan link...','value' => ''.e($data->demo_url).'','name' => 'demo_url','link' => ''.e(url('/')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea)): ?>
<?php $attributes = $__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea; ?>
<?php unset($__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea)): ?>
<?php $component = $__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea; ?>
<?php unset($__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea); ?>
<?php endif; ?>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginal3978e897aae31f6a8181d56d7a541d3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3978e897aae31f6a8181d56d7a541d3d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.textareainput','data' => ['title' => 'Deskripsi','placeholder' => 'Masukkan Deskripsi','value' => ''.e($data->description).'','name' => 'description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.component.textareainput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Deskripsi','placeholder' => 'Masukkan Deskripsi','value' => ''.e($data->description).'','name' => 'description']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3978e897aae31f6a8181d56d7a541d3d)): ?>
<?php $attributes = $__attributesOriginal3978e897aae31f6a8181d56d7a541d3d; ?>
<?php unset($__attributesOriginal3978e897aae31f6a8181d56d7a541d3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3978e897aae31f6a8181d56d7a541d3d)): ?>
<?php $component = $__componentOriginal3978e897aae31f6a8181d56d7a541d3d; ?>
<?php unset($__componentOriginal3978e897aae31f6a8181d56d7a541d3d); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal04caa49f939f2131c336aade823a06cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04caa49f939f2131c336aade823a06cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.submitbutton','data' => ['title' => 'Edit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.component.submitbutton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04caa49f939f2131c336aade823a06cf)): ?>
<?php $attributes = $__attributesOriginal04caa49f939f2131c336aade823a06cf; ?>
<?php unset($__attributesOriginal04caa49f939f2131c336aade823a06cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04caa49f939f2131c336aade823a06cf)): ?>
<?php $component = $__componentOriginal04caa49f939f2131c336aade823a06cf; ?>
<?php unset($__componentOriginal04caa49f939f2131c336aade823a06cf); ?>
<?php endif; ?>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Byoo.link\resources\views/admin/template/edit.blade.php ENDPATH**/ ?>