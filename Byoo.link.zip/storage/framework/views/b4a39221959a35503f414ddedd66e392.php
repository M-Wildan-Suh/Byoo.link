<?php if (isset($component)) { $__componentOriginalfef0857b03f2ee29d91db298d4041a2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfef0857b03f2ee29d91db298d4041a2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.layout.online-shop','data' => ['admin' => $admin,'data' => $data]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.layout.online-shop'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin),'data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data)]); ?>
    <div class=" min-h-screen"></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfef0857b03f2ee29d91db298d4041a2f)): ?>
<?php $attributes = $__attributesOriginalfef0857b03f2ee29d91db298d4041a2f; ?>
<?php unset($__attributesOriginalfef0857b03f2ee29d91db298d4041a2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfef0857b03f2ee29d91db298d4041a2f)): ?>
<?php $component = $__componentOriginalfef0857b03f2ee29d91db298d4041a2f; ?>
<?php unset($__componentOriginalfef0857b03f2ee29d91db298d4041a2f); ?>
<?php endif; ?><?php /**PATH C:\Byoo.link\resources\views/guest/online-shop/link.blade.php ENDPATH**/ ?>