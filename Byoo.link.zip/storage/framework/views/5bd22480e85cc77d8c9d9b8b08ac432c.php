
<div class="" x-data="{open : false}">
    <div class=" fixed top-0 left-0 grid grid-col-3 w-full bg-white/80 backdrop-blur-md px-4 md:px-8 py-4 z-10">
        <div class=" w-full max-w-[1080px] mx-auto flex items-center justify-between">
            <div class=" w-44 h-12 flex items-center overflow-hidden">
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
            </div>
            <div class=" hidden md:flex flex-row gap-6 items-center text-neutral-500">
                <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('home')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('home')).'']); ?>Home <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('template')).'','active' => ''.e(request()->routeIs('template')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('template')).'','active' => ''.e(request()->routeIs('template')).'']); ?>Template <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('')).'']); ?>Tutorial <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('my.web')).'','active' => ''.e(request()->routeIs('my.web')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('my.web')).'','active' => ''.e(request()->routeIs('my.web')).'']); ?>My Web <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
                        <form method="POST" class="" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class=" py-1.5 px-5 bg-red-600 rounded-md font-semibold text-white hover:bg-red-900 duration-300">Logout</button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class=" md:mr-0">
                            <button class=" py-1.5 px-5 bg-byolink-2 rounded-md font-semibold text-white hover:bg-black duration-300">Login</button>
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <button @click="open = !open" :class="{'text-third': open, 'text-second': !open}" class=" flex md:hidden gap-2 items-center duration-300">
                <div class=" w-6 h-6">
                    <svg viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 32 32"><path d="M4 10h24a2 2 0 0 0 0-4H4a2 2 0 0 0 0 4zm24 4H4a2 2 0 0 0 0 4h24a2 2 0 0 0 0-4zm0 8H4a2 2 0 0 0 0 4h24a2 2 0 0 0 0-4z" fill="currentColor" class="fill-000000"></path></svg>
                </div>
            </button>
        </div>
    </div>
    <div :class="{'top-20': open, '-translate-y-full top-0': !open}" class=" fixed flex md:hidden flex-col bg-white/70 backdrop-blur-md w-full left-0 justify-center gap-4 font-semibold text-neutral-600 pt-2 px-4 pb-4 duration-300">
        <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('home')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('home')).'']); ?>Home <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('template')).'','active' => ''.e(request()->routeIs('template')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('template')).'','active' => ''.e(request()->routeIs('template')).'']); ?>Template <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('home')).'','active' => ''.e(request()->routeIs('')).'']); ?>Tutorial <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
        <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
                <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('my.web')).'','active' => ''.e(request()->routeIs('my.web')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('my.web')).'','active' => ''.e(request()->routeIs('my.web')).'']); ?>My Web <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala3ff42b6a849fdf85740143487adfe04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ff42b6a849fdf85740143487adfe04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.nav-button','data' => ['route' => ''.e(route('profile.edit')).'','active' => ''.e(request()->routeIs('profile.edit')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.nav-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('profile.edit')).'','active' => ''.e(request()->routeIs('profile.edit')).'']); ?>Profile <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $attributes = $__attributesOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__attributesOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ff42b6a849fdf85740143487adfe04)): ?>
<?php $component = $__componentOriginala3ff42b6a849fdf85740143487adfe04; ?>
<?php unset($__componentOriginala3ff42b6a849fdf85740143487adfe04); ?>
<?php endif; ?>
                <form method="POST" class=" flex w-full" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class=" w-full py-2 bg-red-600 rounded-md font-semibold text-white hover:bg-red-900 duration-300">
                        Logout
                    </a>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="md:mr-0">
                    <button class=" w-full py-2 px-4 bg-byolink-2 rounded-md font-semibold text-white hover:bg-byolink-3 duration-300">Login</button>
                </a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\Byoo.link\resources\views/components/guest/navbar.blade.php ENDPATH**/ ?>