<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'description', 'color', 'class', 'type', 'slug']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'description', 'color', 'class', 'type', 'slug']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div x-data="{content: false}" :class="admin ? 'hover:border-green-500' : '' " class=" flex flex-col gap-4 px-3 text-center items-center relative border border-transparent">
    <button x-show="admin" @click="content = true"
        class="absolute top-10 right-8 w-4 aspect-square text-black hover:text-green-500 duration-300 z-10">
        <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M0 14.2V18h3.8l11-11.1L11 3.1 0 14.2ZM17.7 4c.4-.4 1 0 1.4-1.4L15.4.3c-.4-.4-1-.4-1.4 0l-1.8 1.8L16 5.9 17.7 4Z"
                fill="currentColor" fill-rule="evenodd" class="fill-000000"></path>
        </svg>
    </button>

    
    <?php echo $__env->make('admin.'.$type.'.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <p class=" text-2xl <?php echo e($class); ?>"><?php echo e($title == '' ? 'Title' : $title); ?></p>
    <div style="background-color: <?php echo e($color == '' ? 'darkgray' : $color); ?>" class=" w-10 h-[4px]"></div>
    <p class="text-sm "><?php echo nl2br(e($description == '' ? 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt cupiditate quo est deleniti vero culpa ea dicta tempore a obcaecati, ex alias suscipit, quasi ut nam nostrum nulla, velit praesentium?' : $description)); ?></p>
</div>
<?php /**PATH C:\Byoo.link\resources\views/components/guest/component/heading.blade.php ENDPATH**/ ?>