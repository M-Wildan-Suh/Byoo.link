<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['background', 'color', 'gallery', 'class', 'title', 'slug', 'modalstatus']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['background', 'color', 'gallery', 'class', 'title', 'slug', 'modalstatus']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div x-data="{gallery: <?php echo e($modalstatus ? 'true' : 'false'); ?>}" :class="admin ? 'hover:border-green-500' : '' " style="background-color: <?php echo e($background ?? 'gray'); ?>" class=" w-full flex flex-col gap-4 justify-center items-center py-12 px-4 border border-transparent relative">
    <button x-show="admin" x-show="admin" @click="gallery = true"
            class=" absolute top-14 right-8 w-4 aspect-square hover:text-green-500 duration-300 <?php echo e($class); ?> ">
        <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 14.2V18h3.8l11-11.1L11 3.1 0 14.2ZM17.7 4c.4-.4 1 0 1.4-1.4L15.4.3c-.4-.4-1-.4-1.4 0l-1.8 1.8L16 5.9 17.7 4Z" 
                  fill="currentColor" 
                  fill-rule="evenodd" 
                  class="fill-000000"></path>
        </svg>
    </button>

    
    <?php echo $__env->make('admin.gallery.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <p class=" <?php echo e($class); ?> text-2xl"><?php echo e($title ?? 'Galeri Kami'); ?></p>
    <div style="background-color: <?php echo e($color); ?>" class=" w-10 h-[4px]"></div>
    <div class=" w-full grid grid-cols-3 gap-2">
        <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="gallery" class="flex items-center justify-center w-full aspect-[4/3] rounded overflow-hidden relative">
                <a class=" w-full h-full" href="<?php echo e(asset('storage/images/gallery/' . $item->image)); ?>" data-caption="<?php echo e($item->image_alt); ?>" aria-label="<?php echo e($item->image_alt); ?>">
                    <div class="absolute w-full h-full top-0 left-0 duration-300 hover:bg-black/30 z-10"></div>
                    <div x-data="{ src: '<?php echo e(asset('storage/images/gallery/' . $item->image)); ?>', isLoading: true, observer: null }"
                        x-init="() => {
                        observer = new IntersectionObserver(entries => {
                            entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                const img = new Image();
                                img.src = '<?php echo e(asset('storage/images/gallery/' . $item->image)); ?>';
                                img.onload = () => {
                                src = img.src;
                                isLoading = false;
                                };
                                observer.disconnect();
                            }
                            });
                        });
                        observer.observe($el);
                        }"
                        class="relative w-full h-full flex items-center object-cover">
                    
                        <!-- Placeholder / Loader -->
                        <div x-show="isLoading" class="absolute inset-0 flex items-center justify-center bg-gray-100">
                            <svg class="animate-spin h-8 w-8 text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </div>
                        
                        <!-- Image -->
                        <img :src="src" 
                            x-show="!isLoading" 
                            class="w-full h-full object-cover"
                            alt="<?php echo e($item->image_alt); ?>">
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<script>
    window.onload = function() {
        Fancybox.bind('#gallery a', {
            groupAll: true,
        });
    };
</script><?php /**PATH C:\Byoo.link\resources\views/components/guest/component/gallery.blade.php ENDPATH**/ ?>