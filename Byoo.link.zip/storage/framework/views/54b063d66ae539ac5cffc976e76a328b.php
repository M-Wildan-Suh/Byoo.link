<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'admin', 'data']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'admin', 'data']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!DOCTYPE html>
<html class=" scroll-smooth" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        
        <style>
            /* latin-ext */
            @font-face {
                font-family: 'Bebas Neue';
                font-style: normal;
                font-weight: 400;
                font-display: swap;
                src: url(https://fonts.gstatic.com/s/bebasneue/v14/JTUSjIg69CK48gW7PXoo9Wdhyzbi.woff2) format('woff2');
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: 'Bebas Neue';
                font-style: normal;
                font-weight: 400;
                font-display: swap;
                src: url(https://fonts.gstatic.com/s/bebasneue/v14/JTUSjIg69CK48gW7PXoo9Wlhyw.woff2) format('woff2');
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
        </style>

        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@simonwep/pickr/dist/themes/nano.min.css"/>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css"/>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        
    </head>
    <body class="font-sans antialiased">
        <div x-data="{ admin: <?php echo e($admin ? 'true' : 'false'); ?> }" style="background-color: <?php echo e($data->templatecolor->bg_color ?? 'white'); ?>" class=" w-full max-w-[420px] min-h-screen mx-auto sm:my-8 rounded-lg shadow-lg shadow-black/35">
            
            <?php echo $__env->make('components.guest.component.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($admin): ?>
                <?php echo $__env->make('components.guest.component.adminmode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php echo e($slot); ?>

            
            <?php if (isset($component)) { $__componentOriginal74e25cd59fc70c905722c1d8717148d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74e25cd59fc70c905722c1d8717148d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.footer','data' => ['slug' => ''.e($data->url).'','background' => $data->templatecolor->main_color ?? 'black','phonecolor' => $data->templatecolor->third_color ?? '#1d588d','wacolor' => $data->templatecolor->fourth_color ?? '#25D366','notlp' => ''.e($data->contact->no_tlp ?? '').'','nowa' => ''.e($data->contact->no_wa ?? '').'','class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->main_color ?? 'black'),'phonecolor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->third_color ?? '#1d588d'),'wacolor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->fourth_color ?? '#25D366'),'notlp' => ''.e($data->contact->no_tlp ?? '').'','nowa' => ''.e($data->contact->no_wa ?? '').'','class' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74e25cd59fc70c905722c1d8717148d2)): ?>
<?php $attributes = $__attributesOriginal74e25cd59fc70c905722c1d8717148d2; ?>
<?php unset($__attributesOriginal74e25cd59fc70c905722c1d8717148d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74e25cd59fc70c905722c1d8717148d2)): ?>
<?php $component = $__componentOriginal74e25cd59fc70c905722c1d8717148d2; ?>
<?php unset($__componentOriginal74e25cd59fc70c905722c1d8717148d2); ?>
<?php endif; ?>
        </div>
    </body>
    
    
    

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@simonwep/pickr/dist/pickr.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
</html>
<?php /**PATH C:\Byoo.link\resources\views/components/guest/layout/online-shop.blade.php ENDPATH**/ ?>