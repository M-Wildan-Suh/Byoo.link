<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['route', 'active']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['route', 'active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<a href="<?php echo e(route($route)); ?>" class=" <?php echo e(request()->routeIs($active) ? 'bg-byolink-3' : 'bg-byolink-1'); ?> w-full py-1.5 rounded-md text-center text-white font-black hover:bg-byolink-3 duration-300 relative">
    <div class=" absolute top-1/2 -translate-y-1/2 left-2 w-4 aspect-square">
        <?php echo e($svg); ?>

    </div>
    <p><?php echo e($slot); ?></p>
    <div class=" absolute top-1/2 -translate-y-1/2 right-2 w-4 aspect-square">
        <?php echo e($svg); ?>

    </div>
</a><?php /**PATH C:\Byoo.link\resources\views/components/admin/mobile-navbutton.blade.php ENDPATH**/ ?>