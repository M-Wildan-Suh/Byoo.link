<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'placeholder', 'name', 'value', 'xModel' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'placeholder', 'name', 'value', 'xModel' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class=" w-full">
    <div class=" flex flex-col gap-2 text-sm sm:text-base font-medium">
        <label for="<?php echo e($name); ?>"><?php echo e($title); ?></label>
        <textarea name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder); ?>" 
        <?php if($xModel): ?>
            <?php echo e($xModel ? 'x-model='.$xModel : ''); ?> 
            x-bind:textContent="<?php echo e($xModel ? '' : $value); ?>" 
        <?php endif; ?> 
        class=" min-h-32 text-sm sm:text-base font-normal rounded-md border border-byolink-1 focus:ring-byolink-3 focus:border-byolink-3 bg-neutral-100" cols="30" rows="4"><?php echo e($value); ?></textarea>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const textarea = document.getElementById('<?php echo e($name); ?>');
    
            textarea.addEventListener('input', function () {
                this.style.height = 'auto'; // Reset height
                this.style.height = this.scrollHeight + 'px'; // Set new height based on content
            });
    
            // Initialize height based on initial content
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        });
    </script>
</div><?php /**PATH C:\Byoo.link\resources\views/components/admin/component/textareainput.blade.php ENDPATH**/ ?>