<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['color', 'tag', 'slug', 'modalstatus', 'tagposition']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['color', 'tag', 'slug', 'modalstatus', 'tagposition']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div x-data="{tag: <?php echo e($modalstatus ? 'true' : 'false'); ?>}" :class="admin ? 'hover:border-green-500' : '' " class=" w-full flex flex-row flex-wrap px-4 gap-2 items-center justify-center relative border border-transparent">
    <button x-show="admin" @click="tag = true"
            class=" group absolute right-8 -top-5 w-4 aspect-square text-black hover:text-green-500 duration-300 ">
        <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 14.2V18h3.8l11-11.1L11 3.1 0 14.2ZM17.7 4c.4-.4 1 0 1.4-1.4L15.4.3c-.4-.4-1-.4-1.4 0l-1.8 1.8L16 5.9 17.7 4Z" 
                  fill="currentColor" 
                  fill-rule="evenodd" 
                  class="fill-000000"></path>
        </svg>
    </button>

    
    <?php echo $__env->make('admin.tag.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($tag->isEmpty()): ?>
    <div style="background-color: <?php echo e($color); ?>" class="cursor-default px-2 py-1 rounded-sm text-white text-sm">
        Tag
    </div>
    <?php else: ?>
        <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="background-color: <?php echo e($color); ?>" class="cursor-default px-2 py-1 rounded-sm text-white text-sm">
                <?php echo e($item->tag); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div><?php /**PATH C:\Byoo.link\resources\views/components/guest/component/tags.blade.php ENDPATH**/ ?>