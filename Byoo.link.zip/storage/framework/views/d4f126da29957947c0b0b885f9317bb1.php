<?php if (isset($component)) { $__componentOriginalfef0857b03f2ee29d91db298d4041a2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfef0857b03f2ee29d91db298d4041a2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.layout.online-shop','data' => ['admin' => $admin,'data' => $data]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.layout.online-shop'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin),'data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data)]); ?>
    <div class=" space-y-6">
        
        <?php if (isset($component)) { $__componentOriginal7dd53bc5cda4fc8b7e636ba5b196d4df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7dd53bc5cda4fc8b7e636ba5b196d4df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest..component.banner','data' => ['slug' => ''.e($data->url).'','templatecolor' => $data->templatecolor,'banner' => $data->banner ?? [],'modalstatus' => session('banner', false)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest..component.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','templatecolor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor),'banner' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->banner ?? []),'modalstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('banner', false))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7dd53bc5cda4fc8b7e636ba5b196d4df)): ?>
<?php $attributes = $__attributesOriginal7dd53bc5cda4fc8b7e636ba5b196d4df; ?>
<?php unset($__attributesOriginal7dd53bc5cda4fc8b7e636ba5b196d4df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7dd53bc5cda4fc8b7e636ba5b196d4df)): ?>
<?php $component = $__componentOriginal7dd53bc5cda4fc8b7e636ba5b196d4df; ?>
<?php unset($__componentOriginal7dd53bc5cda4fc8b7e636ba5b196d4df); ?>
<?php endif; ?> 
        
        <div id="tentang-kami" class=" space-y-8 scroll-mt-20">
            
            <?php echo $__env->make('components.guest.component.youtube', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php if (isset($component)) { $__componentOriginale180f9cb0719c94ec48aead3edb32d9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale180f9cb0719c94ec48aead3edb32d9d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.heading','data' => ['slug' => ''.e($data->url).'','title' => ''.e($data->content->head_title ?? '').'','description' => ''.e($data->content->head_desc ?? '').'','color' => ''.e($data->templatecolor->second_color ?? '#EAB653').'','class' => 'font-bold','type' => 'heading']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','title' => ''.e($data->content->head_title ?? '').'','description' => ''.e($data->content->head_desc ?? '').'','color' => ''.e($data->templatecolor->second_color ?? '#EAB653').'','class' => 'font-bold','type' => 'heading']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale180f9cb0719c94ec48aead3edb32d9d)): ?>
<?php $attributes = $__attributesOriginale180f9cb0719c94ec48aead3edb32d9d; ?>
<?php unset($__attributesOriginale180f9cb0719c94ec48aead3edb32d9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale180f9cb0719c94ec48aead3edb32d9d)): ?>
<?php $component = $__componentOriginale180f9cb0719c94ec48aead3edb32d9d; ?>
<?php unset($__componentOriginale180f9cb0719c94ec48aead3edb32d9d); ?>
<?php endif; ?>
        </div>
        
        <script>
            document.getElementById('scrollButton').addEventListener('click', function() {
                document.getElementById('tentang-kami').scrollIntoView({ behavior: 'smooth' });
            });
            window.addEventListener('scroll', function() {
                var tentangKamiElement = document.getElementById('tentang-kami');
                var productButton = document.getElementById('scrollButton');
                var bounding = tentangKamiElement.getBoundingClientRect();
                
                // Tambahkan kelas jika berada di dalam viewport
                if (bounding.top <= window.innerHeight && bounding.bottom >= 0) {
                    productButton.classList.add('text-white');
                } else {
                    productButton.classList.remove('text-white');
                }
            });
        </script>
        
        <div class=" w-full">
            
            <?php if (isset($component)) { $__componentOriginal4736fdbd732803fb0875deb774c48f81 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4736fdbd732803fb0875deb774c48f81 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.separator','data' => ['bgcolor' => ''.e($data->templatecolor->bg_color ?? 'white').'','color' => ''.e($data->templatecolor->main_color ?? 'black').'','type' => $data->template->section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bgcolor' => ''.e($data->templatecolor->bg_color ?? 'white').'','color' => ''.e($data->templatecolor->main_color ?? 'black').'','type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->template->section)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $attributes = $__attributesOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__attributesOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $component = $__componentOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__componentOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.product','data' => ['slug' => ''.e($data->url).'','background' => $data->templatecolor->main_color ?? 'black','title' => $data->content->product_title ?? null,'color' => $data->templatecolor->second_color ?? '#EAB653','product' => $data->product ?? [],'take' => 4,'class' => ' font-bold text-white','modulstatus' => session('product', false),'type' => $data->template->product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->main_color ?? 'black'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->content->product_title ?? null),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->second_color ?? '#EAB653'),'product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->product ?? []),'take' => 4,'class' => ' font-bold text-white','modulstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('product', false)),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->template->product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $attributes = $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $component = $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginal4736fdbd732803fb0875deb774c48f81 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4736fdbd732803fb0875deb774c48f81 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.separator','data' => ['bgcolor' => ''.e($data->templatecolor->main_color ?? 'black').'','color' => ''.e($data->templatecolor->bg_color ?? 'white').'','type' => $data->template->section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bgcolor' => ''.e($data->templatecolor->main_color ?? 'black').'','color' => ''.e($data->templatecolor->bg_color ?? 'white').'','type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->template->section)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $attributes = $__attributesOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__attributesOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4736fdbd732803fb0875deb774c48f81)): ?>
<?php $component = $__componentOriginal4736fdbd732803fb0875deb774c48f81; ?>
<?php unset($__componentOriginal4736fdbd732803fb0875deb774c48f81); ?>
<?php endif; ?>
        </div>
        
        <?php if (isset($component)) { $__componentOriginal519d2ccfa03e6ff7a49665b74be46685 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal519d2ccfa03e6ff7a49665b74be46685 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.gallery','data' => ['slug' => ''.e($data->url).'','background' => $data->templatecolor->bg_color ?? 'white','title' => $data->content->gallery_title ?? null,'color' => $data->templatecolor->second_color ?? '#EAB653','gallery' => $data->gallery ?? [],'class' => ' font-bold','modalstatus' => session('gallery', false)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.component.gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => ''.e($data->url).'','background' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->bg_color ?? 'white'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->content->gallery_title ?? null),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->templatecolor->second_color ?? '#EAB653'),'gallery' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data->gallery ?? []),'class' => ' font-bold','modalstatus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('gallery', false))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal519d2ccfa03e6ff7a49665b74be46685)): ?>
<?php $attributes = $__attributesOriginal519d2ccfa03e6ff7a49665b74be46685; ?>
<?php unset($__attributesOriginal519d2ccfa03e6ff7a49665b74be46685); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal519d2ccfa03e6ff7a49665b74be46685)): ?>
<?php $component = $__componentOriginal519d2ccfa03e6ff7a49665b74be46685; ?>
<?php unset($__componentOriginal519d2ccfa03e6ff7a49665b74be46685); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfef0857b03f2ee29d91db298d4041a2f)): ?>
<?php $attributes = $__attributesOriginalfef0857b03f2ee29d91db298d4041a2f; ?>
<?php unset($__attributesOriginalfef0857b03f2ee29d91db298d4041a2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfef0857b03f2ee29d91db298d4041a2f)): ?>
<?php $component = $__componentOriginalfef0857b03f2ee29d91db298d4041a2f; ?>
<?php unset($__componentOriginalfef0857b03f2ee29d91db298d4041a2f); ?>
<?php endif; ?><?php /**PATH C:\Byoo.link\resources\views/guest/online-shop/home.blade.php ENDPATH**/ ?>