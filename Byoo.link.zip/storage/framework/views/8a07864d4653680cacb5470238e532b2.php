<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'placeholder', 'link', 'name', 'value', 'xModel' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'placeholder', 'link', 'name', 'value', 'xModel' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class=" w-full">
    <div class=" flex flex-col gap-2 text-sm sm:text-base font-medium">
        <label for="<?php echo e($name); ?>"><?php echo e($title); ?></label>
        <div class="flex flex-row w-full border border-transparent focus-within:border-byolink-3 focus-within:ring-1 focus-within:ring-byolink-3 rounded-md">
            <label for="<?php echo e($name); ?>" class="py-2 px-3 border border-byolink-1 bg-byolink-1 text-white rounded-l-md"><?php echo e($link); ?></label>
            <input type="text" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" 
                placeholder="<?php echo e($placeholder); ?>"
                <?php if($xModel): ?>
                    <?php echo e($xModel ? 'x-model='.$xModel : ''); ?> 
                    x-bind:value="<?php echo e($xModel ? '' : $value); ?>" 
                <?php endif; ?>
                value="<?php echo e($value); ?>" 
                class="flex-grow min-w-0 text-sm sm:text-base font-normal rounded-r-md border border-byolink-1 focus:ring-0 focus:border-none bg-neutral-100">
        </div>
    </div>
</div><?php /**PATH C:\Byoo.link\resources\views/components/admin/component/linkinput.blade.php ENDPATH**/ ?>