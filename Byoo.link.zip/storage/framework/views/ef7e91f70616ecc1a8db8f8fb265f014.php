<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'name', 'value', 'defaultvalue', 'xModel'=> null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'name', 'value', 'defaultvalue', 'xModel'=> null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="w-full">
    <div class="flex flex-col gap-2 text-sm sm:text-base font-medium">
        <label for="<?php echo e($name); ?>"><?php echo e($title); ?></label>
        <div class="grid grid-cols-2 gap-3">
            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-row gap-2 items-center">
                    <input 
                        type="radio" 
                        class="text-byolink-1 ring-0 focus:ring-byolink-1 checked:ring-byolink-1" 
                        name="<?php echo e($name); ?>" 
                        id="<?php echo e($name); ?>" 
                        <?php if($xModel): ?>
                            <?php echo e($xModel ? 'x-model='.$xModel : ''); ?> 
                            x-bind:value="<?php echo e($xModel ? '' : $defaultvalue); ?>" 
                        <?php endif; ?>
                        value="<?php echo e($item['value']); ?>" 
                        <?php if($item['value'] == $defaultvalue || $loop->first && !$defaultvalue): ?> checked <?php endif; ?>
                    >
                    <label for="<?php echo e($name); ?>"><?php echo e($item['label']); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Byoo.link\resources\views/components/admin/component/radioinput.blade.php ENDPATH**/ ?>