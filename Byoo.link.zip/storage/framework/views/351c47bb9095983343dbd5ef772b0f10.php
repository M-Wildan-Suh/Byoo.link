<div class=" w-full h-full">
    <div class=" w-full h-1/2"></div>
    <div style="background-color: <?php echo e($color ?? 'black'); ?>" class=" w-full h-1/2"></div>
</div><?php /**PATH C:\Byoo.link\resources\views/components/guest/component/separator/flat.blade.php ENDPATH**/ ?>