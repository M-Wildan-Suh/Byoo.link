<?php if (isset($component)) { $__componentOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.user','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" w-full h-screen bg-cover text-white">
        <div class=" bg-byolink-1 h-[calc(100vh-40px)] md:px-8 pt-[88px]">
            <div class=" w-full h-full max-w-[1080px] mx-auto grid grid-cols-2 gap-16">
                <div class=" flex flex-col gap-4 justify-center">
                    <p class=" text-4xl font-semibold">Tautan bio sosmed terbaik keren dan menarik!</p>
                    <p>Maksimalkan kehadiranmu di dunia sosial media dengan tautan bio yang paling efektif! Jelajahi tautan-tautan terbaik yang mengarahkan ke konten menarik, profil sosial media, dan informasi terbaru</p>
                    <div class=" pt-3">
                        <button class=" px-4 py-2 bg-byolink-2 hover:bg-[#09092a] duration-300 rounded-md font-medium">Hubungi Sekarang</button>
                    </div>
                </div>
                <div class=" flex items-center">
                    <div class=" w-full aspect-square flex items-center">
                        <img src="https://i0.wp.com/byo.my.id/wp-content/uploads/2023/08/banner-byo-2.png?w=800&ssl=1" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class=" w-full h-10">
            <svg id="visual" viewBox="0 0 1080 50" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><path d="M0 27L16.3 24.7C32.7 22.3 65.3 17.7 98 16.5C130.7 15.3 163.3 17.7 196.2 21.7C229 25.7 262 31.3 294.8 33.7C327.7 36 360.3 35 393 33.7C425.7 32.3 458.3 30.7 491 26.3C523.7 22 556.3 15 589 15.5C621.7 16 654.3 24 687 28.5C719.7 33 752.3 34 785.2 31.2C818 28.3 851 21.7 883.8 19.5C916.7 17.3 949.3 19.7 982 19.5C1014.7 19.3 1047.3 16.7 1063.7 15.3L1080 14L1080 0L1063.7 0C1047.3 0 1014.7 0 982 0C949.3 0 916.7 0 883.8 0C851 0 818 0 785.2 0C752.3 0 719.7 0 687 0C654.3 0 621.7 0 589 0C556.3 0 523.7 0 491 0C458.3 0 425.7 0 393 0C360.3 0 327.7 0 294.8 0C262 0 229 0 196.2 0C163.3 0 130.7 0 98 0C65.3 0 32.7 0 16.3 0L0 0Z" fill="#3b82f6"></path><path d="M0 49L16.3 47.8C32.7 46.7 65.3 44.3 98 42C130.7 39.7 163.3 37.3 196.2 37C229 36.7 262 38.3 294.8 40.3C327.7 42.3 360.3 44.7 393 44.2C425.7 43.7 458.3 40.3 491 38.2C523.7 36 556.3 35 589 34.5C621.7 34 654.3 34 687 34.8C719.7 35.7 752.3 37.3 785.2 36.5C818 35.7 851 32.3 883.8 31.8C916.7 31.3 949.3 33.7 982 35.5C1014.7 37.3 1047.3 38.7 1063.7 39.3L1080 40L1080 12L1063.7 13.3C1047.3 14.7 1014.7 17.3 982 17.5C949.3 17.7 916.7 15.3 883.8 17.5C851 19.7 818 26.3 785.2 29.2C752.3 32 719.7 31 687 26.5C654.3 22 621.7 14 589 13.5C556.3 13 523.7 20 491 24.3C458.3 28.7 425.7 30.3 393 31.7C360.3 33 327.7 34 294.8 31.7C262 29.3 229 23.7 196.2 19.7C163.3 15.7 130.7 13.3 98 14.5C65.3 15.7 32.7 20.3 16.3 22.7L0 25Z" fill="#aab9f7"></path><path d="M0 51L16.3 51C32.7 51 65.3 51 98 51C130.7 51 163.3 51 196.2 51C229 51 262 51 294.8 51C327.7 51 360.3 51 393 51C425.7 51 458.3 51 491 51C523.7 51 556.3 51 589 51C621.7 51 654.3 51 687 51C719.7 51 752.3 51 785.2 51C818 51 851 51 883.8 51C916.7 51 949.3 51 982 51C1014.7 51 1047.3 51 1063.7 51L1080 51L1080 38L1063.7 37.3C1047.3 36.7 1014.7 35.3 982 33.5C949.3 31.7 916.7 29.3 883.8 29.8C851 30.3 818 33.7 785.2 34.5C752.3 35.3 719.7 33.7 687 32.8C654.3 32 621.7 32 589 32.5C556.3 33 523.7 34 491 36.2C458.3 38.3 425.7 41.7 393 42.2C360.3 42.7 327.7 40.3 294.8 38.3C262 36.3 229 34.7 196.2 35C163.3 35.3 130.7 37.7 98 40C65.3 42.3 32.7 44.7 16.3 45.8L0 47Z" fill="#f5f5f5"></path></svg>
        </div>
    </div>
    <div class=" w-full h-full max-w-[1080px] mx-auto space-y-14">
        <p class=" text-3xl text-black text-center font-black">Apa Keuntungan Membuat Byoo Web</p>
        <div class=" w-full grid grid-cols-3 gap-6">
            <div class=" w-full aspect-video bg-white shadow-md shadow-black/20 rounded-md"></div>
            <div class=" w-full aspect-video bg-white shadow-md shadow-black/20 rounded-md"></div>
            <div class=" w-full aspect-video bg-white shadow-md shadow-black/20 rounded-md"></div>
        </div>
    </div>
    <div class=" w-full max-w-[1080px] mx-auto">
        <div class=" w-full grid grid-cols-7 gap-14">
            <div class=" col-span-3 aspect-[5/3]">
                <img src="https://img.freepik.com/free-vector/hand-drawn-flat-design-homepage-illustration_23-2149243391.jpg?t=st=1730696727~exp=1730700327~hmac=f6b413ffdca1a741e81fc50de2711efcd2a3a63d16336268a9a6b71c33797c93&w=900" alt="">
            </div>
            <div class=" col-span-4 flex justify-center flex-col gap-4">
                <p class=" text-2xl font-black">Website fleksible yang dapat di edit secara realtime.</p>
                <p class=" text-neutral-600">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt, sint aspernatur ipsa ea quasi adipisci ipsum, et voluptate possimus veritatis sequi fuga dolores similique perspiciatis quae quo ratione vel ab.</p>
            </div>
        </div>
    </div>
    <div class=" w-full max-w-[1080px] mx-auto rounded-md bg-byolink-3 p-8">
        <div class=" w-full grid grid-cols-3 gap-8 text-white">
            <div class=" flex flex-col h-full justify-between items-center gap-6">
                <div class=" w-20 p-4 aspect-square rounded-full bg-byolink-2">
                    <svg viewBox="0 0 256 256" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 256 256"><path d="M128 65.8c13.8 0 25-11.2 25-25s-11.2-25-25-25-25 11.2-25 25c0 13.7 11.2 25 25 25zm0-39.8c8.1 0 14.8 6.6 14.8 14.8 0 8.1-6.6 14.8-14.8 14.8-8.1 0-14.8-6.6-14.8-14.8.1-8.2 6.7-14.8 14.8-14.8zM73.6 162.9c-2.1.5-3.7 2.4-3.8 4.6L66 226c-.1 2.3-2 4-4.3 4h-29c-2.3 0-4.2-1.8-4.3-4l-3.9-58.4c-.1-2.1-1.6-3.9-3.6-4.5-1.1-.3-4.3-1.3-4.8-1.9-.4-.6-.6-3.9-.7-5.6l-3.5-61.9c5-1.5 13.2-4.1 17.5-5.5l14.3 13.4c2 1.8 5 1.8 7 0L65 88.2c1.4.4 3.1 1 5 1.6 2.7.9 5.6-.6 6.4-3.3.9-2.7-.6-5.6-3.3-6.4-4.3-1.4-7.8-2.5-7.8-2.5-1.8-.6-3.7-.1-5.1 1.1l-13 12.2-13-12.2c-1.4-1.3-3.3-1.7-5.1-1.1 0 0-13.7 4.4-20.6 6.5-4.3 1.3-6.9 4.7-6.9 9.2v1.1l3.4 61s0 .9.1 1.1c.6 9 1.9 12.3 9.4 15.2l3.6 55c.5 7.6 6.9 13.6 14.5 13.6h29c7.6 0 14-6 14.5-13.6l3.7-57c.4-1 .4-2.2.1-3.3-.7-2.7-3.6-4.2-6.3-3.5zM47.1 69.3c13.8 0 25-11.2 25-25s-11.2-25-25-25-25 11.2-25 25 11.3 25 25 25zm0-39.7c8.1 0 14.8 6.6 14.8 14.8s-6.6 14.8-14.8 14.8c-8.1 0-14.8-6.6-14.8-14.8S39 29.6 47.1 29.6zM166.7 83.9c-6.9-2.1-20.6-6.5-20.6-6.5-1.8-.6-3.7-.1-5.1 1.1l-13 12.2-13-12.2c-1.4-1.3-3.3-1.7-5.1-1.1 0 0-13.7 4.4-20.6 6.5-4.4 1.3-6.9 4.7-6.9 9.2l3.4 62.3.1 1c.6 9 1.9 12.4 9.4 15.2l3.6 55c.5 7.6 6.9 13.6 14.5 13.6h29.1c7.6 0 14-6 14.5-13.6l3.6-55c7.5-2.9 8.8-6.3 9.4-15.2l3.5-62.4v-.9c.1-4.6-2.4-7.9-6.8-9.2zm-6.8 70.7-.1 1c-.1 1.6-.3 4.8-.7 5.4-.5.6-3.8 1.6-4.9 1.9-2 .6-3.5 2.4-3.6 4.6l-3.8 58.4c-.1 2.3-2 4-4.3 4h-29.1c-2.3 0-4.1-1.8-4.3-4l-3.8-58.4c-.1-2.1-1.6-3.9-3.6-4.6-1.1-.3-4.3-1.3-4.8-1.9-.4-.6-.6-3.9-.7-5.4l-3.5-61.9v-.3c5-1.5 13.2-4.1 17.5-5.5l14.3 13.4c2 1.8 5 1.8 7 0L145.8 88c4.3 1.4 12.5 4 17.5 5.5l-3.4 61.1zM247.6 83.9c-6.9-2.1-20.6-6.5-20.6-6.5-1.8-.6-3.7-.1-5.1 1.1l-13 12.2-13-12.2c-1.4-1.3-3.3-1.7-5.1-1.1 0 0-3.5 1.1-7.8 2.5-2.7.9-4.2 3.7-3.3 6.4.9 2.7 3.7 4.2 6.4 3.3 1.9-.6 3.6-1.2 5-1.6l14.3 13.4c2 1.8 5 1.8 7 0L226.7 88c4.3 1.4 12.4 3.9 17.5 5.5l-3.4 61.1-.1 1c-.1 1.6-.3 4.8-.7 5.4-.5.6-3.8 1.6-4.9 1.9-2 .6-3.5 2.4-3.6 4.6l-3.8 58.4c-.2 2.3-2.1 4-4.3 4h-29.1c-2.2 0-4.1-1.8-4.3-4l-3.9-58.4c-.1-2.1-1.8-3.9-3.8-4.6-2.7-.9-5.4.6-6.3 3.3-.3 1-.3 2.1 0 3l3.8 57.4c.5 7.6 6.8 13.6 14.5 13.6h29.1c7.6 0 14-6 14.5-13.6l3.6-55c7.5-2.9 8.8-6.2 9.4-15.1 0-.4.1-1.3.1-1.3l3.4-61.3V93c0-4.4-2.5-7.8-6.8-9.1zM208.9 69.3c13.8 0 25-11.2 25-25s-11.2-25-25-25-25 11.2-25 25 11.2 25 25 25zm0-39.7c8.1 0 14.8 6.6 14.8 14.8s-6.6 14.8-14.8 14.8c-8.1 0-14.8-6.6-14.8-14.8s6.6-14.8 14.8-14.8z" fill="currentColor" class="fill-000000"></path></svg>
                </div>
                <div class=" text-center">
                    <p class=" text-4xl font-bold">1358+</p>
                    <p class=" text-lg">Klient Kami</p>
                </div>
            </div>
            <div class=" flex flex-col h-full justify-between items-center gap-6">
                <div class=" w-20 p-4 aspect-square rounded-full bg-byolink-2">
                    <svg viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><g fill="currentColor" class="fill-263238"><circle cx="7.5" cy="5.5" r=".5"></circle><circle cx="5.5" cy="5.5" r=".5"></circle><circle cx="3.5" cy="5.5" r=".5"></circle><path d="M30.5 8h-29a.5.5 0 0 1 0-1h29a.5.5 0 0 1 0 1z"></path><path d="M29.5 3h-27C1.673 3 1 3.673 1 4.5v23c0 .827.673 1.5 1.5 1.5h27c.827 0 1.5-.673 1.5-1.5v-23c0-.827-.673-1.5-1.5-1.5zm.5 24.5c0 .275-.225.5-.5.5h-27a.501.501 0 0 1-.5-.5v-23c0-.275.225-.5.5-.5h27c.275 0 .5.225.5.5v23z"></path></g><path d="M24.5 22h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0 0 1zM17.5 24h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0 0 1zM17.5 26h5a.5.5 0 0 0 0-1h-5a.5.5 0 0 0 0 1zM24.5 26h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1zM17.5 22h5a.5.5 0 0 0 0-1h-5a.5.5 0 0 0 0 1zM22.5 24h5a.5.5 0 0 0 0-1h-5a.5.5 0 0 0 0 1zM14.5 24h-3a.5.5 0 0 1 0-1h3a.5.5 0 0 1 0 1zM12.5 26h-3a.5.5 0 0 1 0-1h3a.5.5 0 0 1 0 1zM7.5 26h-3a.5.5 0 0 1 0-1h3a.5.5 0 0 1 0 1zM15.5 18h-10a.5.5 0 0 1 0-1h10a.5.5 0 0 1 0 1zM14.5 22h-10a.5.5 0 0 1 0-1h10a.5.5 0 0 1 0 1zM9.5 24h-5a.5.5 0 0 1 0-1h5a.5.5 0 0 1 0 1z" fill="currentColor" class="fill-263238"></path><path d="M27.5 18h-23a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5h23a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5zM5 17h22v-6H5v6z" fill="currentColor" class="fill-263238"></path></svg>
                </div>
                <div class=" text-center">
                    <p class=" text-4xl font-bold">500+</p>
                    <p class=" text-lg">Template Design</p>
                </div>
            </div>
            <div class=" flex flex-col h-full justify-between items-center gap-6">
                <div class=" w-20 p-4 aspect-square rounded-full bg-byolink-2">
                    <svg viewBox="0 0 64 64" class=" w-full h-full" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 64 64"><path d="M58.059 46.74 50 44.262V42.13a9.967 9.967 0 0 0 3-7.129h1c2.757 0 5-2.243 5-5 0-1.627-.793-3.061-2-3.974V22c0-7.72-6.28-14-14-14-1.826 0-3.566.362-5.166 1H35V6c0-2.757-2.243-5-5-5H14c-2.757 0-5 2.243-5 5v3H4c-1.654 0-3 1.346-3 3v24c0 3.859 3.14 7 7 7h28v1.262l-8.059 2.479A6.966 6.966 0 0 0 23 53.432V63h40v-9.568a6.968 6.968 0 0 0-4.941-6.692zm-5.653.354-3.739 6.482-4.097-2.731 4.712-4.712 3.124.961zM41.847 57h2.306l.667 4h-3.64l.667-4zm2.618-2h-2.93l-.841-1.261L43 52.202l2.306 1.537L44.465 55zM48 44.586l-5 5-5-5v-.939c1.473.855 3.178 1.353 5 1.353s3.527-.498 5-1.353v.939zM51 35c0 4.411-3.589 8-8 8-2.953 0-5.532-1.613-6.918-4h2.102A2.996 2.996 0 0 0 41 41h4c1.654 0 3-1.346 3-3s-1.346-3-3-3h-4a2.996 2.996 0 0 0-2.816 2h-2.921A7.953 7.953 0 0 1 35 35v-8.037a12.966 12.966 0 0 0 8-3.555 12.966 12.966 0 0 0 8 3.555V35zm-11 3c0-.552.449-1 1-1h4a1.001 1.001 0 0 1 0 2h-4c-.551 0-1-.448-1-1zm-7-5h-1c-1.654 0-3-1.346-3-3s1.346-3 3-3h1v6zm-2 1.899c.323.066.658.101 1 .101h1c0 .685.07 1.354.202 2H32c-.551 0-1-.448-1-1v-1.101zM54 33h-1v-6h1c1.654 0 3 1.346 3 3s-1.346 3-3 3zm1-11v3.101A4.995 4.995 0 0 0 54 25h-2a10.994 10.994 0 0 1-7.828-3.242L43 20.585l-1.171 1.173A10.998 10.998 0 0 1 34 25h-2c-.342 0-.677.035-1 .101V22c0-6.617 5.383-12 12-12s12 5.383 12 12zM11 6c0-1.654 1.346-3 3-3h16c1.654 0 3 1.346 3 3v3h-2V5H13v4h-2V6zm18 3H15V7h14v2zM3 12c0-.552.449-1 1-1h30.368C31.106 13.565 29 17.538 29 22v3h-4v-2h-6v2H8c-2.757 0-5-2.243-5-5v-8zm20 13v4h-2v-4h2zM3 36V24.889A6.973 6.973 0 0 0 8 27h11v4h6v-4h3.026A4.948 4.948 0 0 0 27 30c0 1.627.793 3.061 2 3.974V36c0 1.654 1.346 3 3 3h1.841a9.991 9.991 0 0 0 1.178 2H8c-2.757 0-5-2.243-5-5zm33.719 10.133 4.712 4.712-4.101 2.734-3.771-6.474 3.16-.972zM25 53.432a4.974 4.974 0 0 1 3.529-4.779l3.066-.943 5.075 8.712 2.359-1.573.918 1.378L39.153 61H33v-5h-2v5h-6v-7.568zM61 61h-6v-5h-2v5h-6.153l-.796-4.774.918-1.377 2.363 1.576 5.034-8.726 3.103.955a4.975 4.975 0 0 1 3.53 4.779V61z" fill="currentColor" class="fill-000000"></path><circle cx="38" cy="29" r="1" fill="currentColor" class="fill-000000"></circle><circle cx="48" cy="29" r="1" fill="currentColor" class="fill-000000"></circle><path d="M15 29h2v2h-2zM11 29h2v2h-2z" fill="currentColor" class="fill-000000"></path></svg>
                </div>
                <div class=" text-center">
                    <p class=" text-4xl font-bold">14</p>
                    <p class=" text-lg">Team Profesional</p>
                </div>
            </div>
        </div>
    </div>
    <div class=" w-full h-full max-w-[1080px] mx-auto space-y-14">
        <p class=" text-3xl text-black text-center font-black">Pilihan Template Byoo</p>
        <div class=" space-y-8">
            <div class=" w-full grid grid-cols-2 gap-6">
                <div class=" w-full bg-white shadow-md shadow-black/20 rounded-md grid grid-cols-7 p-4 gap-4">
                    <div class=" col-span-3 w-full">
                        <img src="https://i0.wp.com/byo.my.id/wp-content/uploads/2023/08/Desain-Thumbnail-Basreng-Mamah-Gilang.png?w=542&ssl=1" alt="">
                    </div>
                    <div class=" col-span-4 flex flex-col justify-between py-3">
                        <div class=" space-y-2">
                            <p class=" text-lg font-semibold">Design Bio Basreng</p>
                            <p class=" text-neutral-600">Cocok Untuk Usaha yang bergerak di bidang Makanan dan Minuman</p>
                        </div>
                        <div class=" space-y-2">
                            <button class=" w-full py-2 bg-byolink-2 hover:bg-byolink-3 text-white rounded-md duration-300">Beli Voucher Template</button>
                            <button class=" w-full py-2 border rounded-md border-neutral-400 hover:text-byolink-1 hover:border-byolink-1 duration-300">Lihat Demo</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" w-full flex justify-center">
                <button class=" py-2 px-4 border rounded-md border-neutral-400 hover:text-byolink-1 hover:border-byolink-1 duration-300">View more</button>
            </div>
        </div>
    </div>
     <?php $__env->slot('additional', null, []); ?> 
        <div class=" w-full flex justify-center bg-byolink-3 md:px-8 py-20 text-white">
            <div class=" text-center space-y-4">
                <p class=" text-3xl font-black">Tunggu Apa lagi ?</p>
                <p>Dengan byo.link Mari Kita Upgrade Bisnis-Bisnis yang ada Di Indonesia menjadi lebih maju</p>
                <button class=" py-2 px-4 border border-white rounded-md hover:text-byolink-1 hover:border-byolink-1 duration-300 hover:bg-white">Beli Voucher</button>
            </div>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5)): ?>
<?php $attributes = $__attributesOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5; ?>
<?php unset($__attributesOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5)): ?>
<?php $component = $__componentOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5; ?>
<?php unset($__componentOriginald0e6a5f122f7d1f17c3b7c09c6c38ef5); ?>
<?php endif; ?>
<?php /**PATH C:\Byoo.link\resources\views/home.blade.php ENDPATH**/ ?>