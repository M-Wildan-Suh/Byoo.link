<?php

namespace App\Http\Controllers;

use App\Models\Voucher;
use App\Models\Web;
use Illuminate\Http\Request;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;

class WebController extends Controller
{
    public function webgenerate(Request $request)
    {
        $voucher = Voucher::where('kode', $request->kode)->first();
        if ($voucher) {
            if ($voucher->status === 'not used') {
                $newdata = new Web;

                $newdata->title = $request->name;
                $newdata->url = $request->url;
                $newdata->web_type_id = $voucher->web_type_id;

                $newdata->save();

                $voucher->status = 'used';

                $voucher->save();

                return redirect()->back();
            } else {
                return redirect()->back();
            }
        } else {
            return redirect()->back();
        }
    }

    public function logo($slug, Request $request) 
    {
        $data = Web::where('url', $slug)->first();
        
        if ($data) {
            if ($request->hasFile('image')) {
                if ($request->image !== null) {
                    if ($data->logo) {
                        $path = public_path('storage/images/logo/' . $data->logo);
    
                        if (file_exists($path)) {
                            unlink($path);
                        }
                    }
    
                    $imageFile = $request->file('image');
                    $imageName = time() . '.' . $imageFile->getClientOriginalExtension();
                    $imagePath = public_path('storage/images/logo/');

                    $manager = new ImageManager(new Driver());
                    $image = $manager->read($imageFile->getPathname());
                    $imageFullPath = $imagePath . $imageName . '.webp';
                    $image->save($imageFullPath);

                    $data->logo = $imageName . '.webp';
                }
            }
            $data->save();
        }
        else {
            return redirect()->back();
        }
        
        return redirect()->back();
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Web $web)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Web $web)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Web $web)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Web $web)
    {
        //
    }
}
