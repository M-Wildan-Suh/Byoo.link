<x-app-layout title="User">
    <div class=" w-full p-6 bg-white rounded-md shadow-md shadow-black/20">
        <div class=" w-full grid"></div>
    </div>
</x-app-layout>
