<x-guest.layout.online-shop :admin="$admin" :data="$data">
    <div class=" min-h-screen"></div>
</x-guest.layout.online-shop>