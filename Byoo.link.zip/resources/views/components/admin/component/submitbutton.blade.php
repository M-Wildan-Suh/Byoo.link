@props(['title'])
<div class=" w-full">
    <button class=" w-full py-3 text-sm sm:text-base rounded-md bg-byolink-1 text-white font-semibold hover:bg-byolink-3 duration-300">{{$title}}</button>
</div>