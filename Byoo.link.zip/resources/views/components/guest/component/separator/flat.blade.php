<div class=" w-full h-full">
    <div class=" w-full h-1/2"></div>
    <div style="background-color: {{ $color ?? 'black' }}" class=" w-full h-1/2"></div>
</div>